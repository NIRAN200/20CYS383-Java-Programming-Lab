package com.amrita.jpl.cys21048.ex;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}